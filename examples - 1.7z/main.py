import webview
import GSHEET as GS

"""
This example demonstrates evaluating JavaScript in a web page.
"""


def evaluate_js(window):
  
	val2 = GS.search()

	result = window.evaluate_js = r"""document.getElementById("t").innerHTML = ohshitnadfasdfadf"""
	print(result)
 
class API:
    def run(self, a):
        return 0

if __name__ == '__main__':
	api = API()

	f = open("render_pre_style.html", "r")
	htmlval = f.read()
	f = open("css.html", "r")
	cssval = f.read()
	val = htmlval + cssval
	f = open("render_post_style.html", "r")
	val = val + f.read()

	window = webview.create_window('Run custom JavaScript', html=val, js_api=api)
	webview.start(evaluate_js, window)
