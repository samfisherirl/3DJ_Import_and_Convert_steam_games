import time
import webview

html = '''
<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    function greet() {
      var name_input = document.getElementById('name_input').value;
      pywebview.api.sayHelloTo(name_input).then(showResponse);
    }
    function showResponse(response) {
      var container = document.getElementById('response-container');

      container.innerText = response.message;
      container.style.display = 'block';
    }
    </script>
</head>
<body>
  <div class="parent h-screen">
    <main class="text-center">
      <div class="flex justify-center">
        <input id="name_input" placeholder="enter your name" class="border-2 border-black m-2 p-1" />  
        <button onClick="greet()" class="border-2 border-black m-2 p-1 hover:bg-gray-400">Greet me!</button>
      </div>
      <p id="response-container"></p>
    </main>
  </div>
</body>
</html>

'''

class Api:

    def sayHelloTo(self, name):
        time.sleep(0.1)
        response = {
            'message': 'Hello {0}!'.format(name)
        }
        return response

if __name__ == '__main__':
    api = Api()
    with open('webview_test2.html', 'r') as file:
        html = file.read().replace('\n', '')
    window = webview.create_window('Testing PyWebView', html=html, js_api=api, width=800, height=600)
    webview.start(debug=True) 